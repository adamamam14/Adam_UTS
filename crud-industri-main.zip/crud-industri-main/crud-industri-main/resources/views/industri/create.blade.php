@extends('template')

@section('content')
@section('title', 'create')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-8">
            <div class="card">
                <div class="card-head">
                    <h1 class="text-center">Membuat Industri</h1>
                </div>
                <div class="card-body">
                    <form action="{{route('industri.store')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama Industri</label>
                            <input type="text" name="nama" class="form-control @error('nama') is-invalid @enderror"
                                >
                                @error('nama')
                                    <div class="invalid-feedback">
                                        <i class="bi bi-exclamation-circle-fill"></i>
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                        <div class="mb-3">
                            <label for="deskripsi" class="form-label">Bidang Industri</label>
                            <input type="text" name="deskripsi" class="form-control @error('deskripsi') is-invalid @enderror">
                            @error('deskripsi')
                            <div class="invalid-feedback">
                                <i class="bi bi-exclamation-circle-fill"></i>
                                {{ $message }}
                            </div>
                        @enderror
                        </div>
                        <div class="d-flex">
                            <button type="submit" class="btn btn-primary me-3">Kirim</button>
                            <a href="{{ route('industri.index') }}" class="btn btn-secondary">Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
